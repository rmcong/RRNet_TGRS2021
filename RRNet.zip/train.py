from dataset import *
from network_multiscale_final import *

os.environ['CUDA_VISIBLE_DEVICES'] = '6, 7'
gpu_devices = list(np.arange(torch.cuda.device_count()))
multi_gpu = len(gpu_devices) > 1
########################################################################################################################
output_folder = r'./Outputs_GR'
checkpoints_folder = r'./Checkpoints/trained'
dataset_root = r'./train_and_test'
pth_name = '1-1-'
batch_size = 8 * len(gpu_devices)
init_lr = 5e-5
min_lr = 5e-6
train_epoch = 300

train_loader = data.DataLoader(EORSSD(dataset_root, 'train', aug=True),
                               shuffle=True, batch_size=batch_size, num_workers=8, drop_last=True, pin_memory = True)
test_loader = data.DataLoader(EORSSD(dataset_root, 'test', aug=False),
                              shuffle=False, batch_size=batch_size, num_workers=8, drop_last=False, pin_memory = True)

net = DAFNet(bb_type='ResNet50', return_loss=True).cuda()
# net.load_state_dict(torch.load(os.path.join(checkpoints_folder, 'rr.pth')))
########################################################################################################################

optimizer = optim.Adam([{'params': net.encoder.parameters(), 'lr': init_lr * 0.5},
                        {'params': net.decoder.parameters(), 'lr': init_lr * 0.5},
                        {'params': net.head.parameters(), 'lr': init_lr}], weight_decay=1e-5)
scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=train_epoch, eta_min=min_lr)


if multi_gpu==True:
    net = nn.DataParallel(net, gpu_devices)
    print('Use {} GPUs'.format(len(gpu_devices)))
else:
    print('Use a single GPU')

net.train()

for epc in range(1, train_epoch+1):
    loss_record = 0
    t_start = time.time()
    N = 0
    for index, (image, label, name) in enumerate(train_loader):
        # prepare input data
        image, label = image.cuda(), label.cuda()
        B = image.size(0)
        # forward
        optimizer.zero_grad()
        M, E, losses = net(image, label, True)
        # compute loss
        loss = losses.mean()
        loss_record += loss.item() * B
        N += B
        loss.backward()
        optimizer.step()

    if epc > 100:
        cache_model(net, os.path.join(checkpoints_folder, pth_name + str(epc) + '.pth'), multi_gpu)

    # print training information
    t_end = time.time()
    dlt = str(int(t_end-t_start))
    loss_record = np.around(loss_record / N, 6)
    print('epoch:{}, time:{}s, total loss:{}'.format(epc, dlt, loss_record))