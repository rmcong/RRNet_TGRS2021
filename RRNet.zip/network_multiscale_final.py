from modules import *
import initializer


class Encoder(nn.Module):
    def __init__(self, bb_type):
        super(Encoder, self).__init__()
        ch, dr = backbone_info(bb_type)
        self.C1, self.C2, self.C3, self.C4, self.C5 = self.build_backbone(bb_type)

        self.SA_multiscale1 = SpatialAttention_multiscale(ch[0])
        self.SA_multiscale2 = SpatialAttention_multiscale(ch[1])


        self.GR_pixel3 = GR(ch[2])
        self.GR_pixel4 = GR(ch[3])
        self.GR_channel3 = GR_channel(56 * 56, squeeze_ratio=32)
        self.GR_channel4 = GR_channel(28 * 28)
        # self.GR_pixel5 = GR(ch[4])

    def forward(self, Im):
        # stage-1
        F1 = self.C1(Im)
        A1_en = self.SA_multiscale1(F1)

        F2 = self.C2(F1)
        A2_en = self.SA_multiscale2(F2)

        F3 = self.C3(F2)
        F3 = self.GR_pixel3(F3)
        F3 = self.GR_channel3(F3)

        F4 = self.C4(F3)
        F4 = self.GR_pixel4(F4)
        F4 = self.GR_channel4(F4)

        F5 = self.C5(F4)
        # F5 = self.GR_pixel5(F5)

        return F1, F2, F3, F4, F5, A1_en, A2_en

    def build_backbone(self, bb_type):
        if bb_type == 'ResNet50':
            bb = torch.load('./Checkpoints/warehouse/backbone_r.pth')
        return bb.C1, bb.C2, bb.C3, bb.C4, bb.C5

    def initialize(self):
        weight_init(self)


class Decoder(nn.Module):
    def __init__(self, bb_type):
        super(Decoder, self).__init__()
        ch, dr = backbone_info(bb_type)
        self.fd_4 = FeatureDecoding(2048, 1024, 1024, is_upsample=True)
        self.fd_3 = FeatureDecoding(1024, 512, 512, is_upsample=True)
        self.fd_s = FeatureDecoding(256, 64, 256, is_upsample=False)
        self.fd_o = FeatureDecoding(512, 256, 256, is_upsample=True)
        # self.fd_14 = FeatureDecoding_US4(1024, 64, 64, is_upsample=True)

        self.conv = Conv1ReLU(768, 256)

        # self.GR_D4 = GloRe_Unit(num_in=1024, num_mid=256)
        # self.GR_D3 = GloRe_Unit(num_in=512, num_mid=128)
        # self.GR_Ds = GloRe_Unit(num_in=256, num_mid=64)
        # self.GR_Do = GloRe_Unit(num_in=256, num_mid=64)

        # self.fd = FeatureDecoding_MultiScale()

    def forward(self, F1, F2, F3, F4, F5, A1_de, A2_de):
        F1 = RC(F1, A1_de)
        F2 = RC(F2, A2_de)
        Ds = self.fd_s(F2, F1)
        D4 = self.fd_4(F5, F4)
        D3 = self.fd_3(D4, F3)
        Do = self.fd_o(D3, Ds)
        return Do

    def initialize(self):
        weight_init(self)


class DAFNet(nn.Module):
    def __init__(self, bb_type='ResNet50', return_loss=False):
        super(DAFNet, self).__init__()
        assert bb_type in ['ResNet50']
        self.return_loss = return_loss
        ch, dr = backbone_info(bb_type)

        # 只为encoder加载部分参数
        self.encoder = Encoder(bb_type)

        self.decoder = Decoder(bb_type)

        mask_head_1 = SaliencyHead(256)
        edge_head_1 = SaliencyHead(ch[0])
        mask_head_2 = SaliencyHead(ch[1])
        edge_head_2 = SaliencyHead(ch[1])
        mask_head_3 = SaliencyHead(ch[2])
        edge_head_3 = SaliencyHead(ch[2])
        self.head = nn.ModuleList([mask_head_1, edge_head_1,
                                   mask_head_2, edge_head_2,
                                   mask_head_3, edge_head_3])
        self.bce = nn.BCELoss()

    def forward(self, image, label, loss):
        F1, F2, F3, F4, F5, A1_de, A2_de = self.encoder(image)
        # D1, D2, D3, D4 = self.decoder(F1, F2, F3, F4, F5)
        Do = self.decoder(F1, F2, F3, F4, F5, A1_de, A2_de)
        sm = self.head[0](Do)
        if self.return_loss & loss:
            overall_loss = self.compute_loss(sm, sm, label, edge)
            return sm, sm, overall_loss
        else:
            return sm, sm

    def compute_loss(self, M, E, label, edge):
        overall_loss = self.bce(M, label)
        return overall_loss

    def initialize(self):
        weight_init(self)


class Baseline(nn.Module):
    def __init__(self):
        super(Baseline, self).__init__()
        bb_type = 'ResNet50'
        ch, dr = backbone_info(bb_type)
        self.encoder = Encoder(bb_type)
        self.decoder = Decoder(bb_type)
        self.mask_layer = SaliencyHead(256)
        self.bce = nn.BCELoss()

    def forward(self, image, label, edge):
        F1, F2, F3, F4, F5 = self.encoder(image)
        Do = self.decoder(F1, F2, F3, F4, F5)
        sm = self.mask_layer(Do)
        loss = self.bce(sm, label)
        return sm, sm, loss


