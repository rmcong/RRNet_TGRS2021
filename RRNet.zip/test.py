from dataset import *
from network_multiscale_final import *
# from network_transformer import *

#if __name__ == '__main__':

os.environ['CUDA_VISIBLE_DEVICES'] = '7'
gpu_devices = list(np.arange(torch.cuda.device_count()))
multi_gpu = len(gpu_devices) > 1

output_folder = r'./Outputs/Outputs_GR'
###########################################################################################################
checkpoints_folder = r'./Checkpoints/Att_multiscale10'
# dataset_root = r'../dataset/EORSSD/EORSSD_Dev'
dataset_root = r'train_and_test'
# dataset_root = r'hyperspectral'

batch_size = 8

train_loader = data.DataLoader(EORSSD(dataset_root, 'train', aug=True),
                               shuffle=True, batch_size=batch_size, num_workers=8, drop_last=True)

test_loader = data.DataLoader(EORSSD(dataset_root, 'test', aug=False),
                              shuffle=False, batch_size=batch_size, num_workers=8, drop_last=False)

# for i in range(1,31):
# output_folder = r'./Outputs/Outputs_GR'+ str(i)
net = DAFNet(bb_type='ResNet50', return_loss=False).cuda()

############################################################################################################
# NAME_10 = 'dafnet' + str(i) + '0.pth'
# NAME = 'dafnet_min_mae.pth'
NAME = 'dafnet214-9-newPMA.pth'
# NAME = 'dafnet13.pth'

net.load_state_dict(torch.load(os.path.join(checkpoints_folder, NAME)))
if multi_gpu == True:
    net = nn.DataParallel(net, gpu_devices)
    print('Use {} GPUs'.format(len(gpu_devices)))
else:
    print('Use a single GPU')

# check model size
# if not os.path.exists('module_size'):
#     os.makedirs('module_size')
# for name, module in net.named_children():
#     torch.save(module, 'module_size/' + '%s' % name + '.pth')

net.eval()
inf_time = 0
for index, (image, label, prefix) in enumerate(test_loader):
    with torch.no_grad():
        image, label = image.cuda(), label.cuda()
        B = image.size(0)
        t1 = time.time()
        M, E = net(image, label, False)
        t2 = time.time()
        inf_time += (t2 - t1)
        print(t2 - t1)
        smap = M
        for b in range(B):
            path = os.path.join(output_folder, prefix[b] + '.png')
            save_smap(smap[b, ...], path)

print('Finished testing: {} sec'.format(np.around(inf_time, 2)))
