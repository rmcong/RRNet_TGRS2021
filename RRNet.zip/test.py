from dataset import *
from network_multiscale_final import *

os.environ['CUDA_VISIBLE_DEVICES'] = '7'
gpu_devices = list(np.arange(torch.cuda.device_count()))
multi_gpu = len(gpu_devices) > 1

output_folder = r'./Outputs/Outputs_GR'
checkpoints_folder = r'./Checkpoints/trained'
dataset_root = r'train_and_test'

batch_size = 8

train_loader = data.DataLoader(EORSSD(dataset_root, 'train', aug=True),
                               shuffle=True, batch_size=batch_size, num_workers=8, drop_last=True)
test_loader = data.DataLoader(EORSSD(dataset_root, 'test', aug=False),
                              shuffle=False, batch_size=batch_size, num_workers=8, drop_last=False)

net = DAFNet(bb_type='ResNet50', return_loss=False).cuda()

NAME = 'RRNet_pretrained_2.pth'
net.load_state_dict(torch.load(os.path.join(checkpoints_folder, NAME)))

if multi_gpu == True:
    net = nn.DataParallel(net, gpu_devices)
    print('Use {} GPUs'.format(len(gpu_devices)))
else:
    print('Use a single GPU')

net.eval()

inf_time = 0
for index, (image, label, prefix) in enumerate(test_loader):
    with torch.no_grad():
        image, label = image.cuda(), label.cuda()
        B = image.size(0)
        t1 = time.time()
        M, E = net(image, label, False)
        t2 = time.time()
        inf_time += (t2 - t1)
        # print(t2 - t1)
        smap = M
        for b in range(B):
            path = os.path.join(output_folder, prefix[b] + '.png')
            save_smap(smap[b, ...], path)

print('Finished testing: {} sec'.format(np.around(inf_time, 2)))
